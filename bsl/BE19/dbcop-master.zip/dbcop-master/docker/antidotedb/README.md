In one console,

    docker-compose up

When the nodes are ready, in another console,

    docker exec antidote1 ./connect.erl 3

P.S. above setup is adapted directly from [AntidoteDB documentation](https://antidotedb.gitbook.io/documentation/#create-a-cluster).

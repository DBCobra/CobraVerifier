For a cluster of size 4

    docker-compose up -d --scale roach0=1 --scale roach=3

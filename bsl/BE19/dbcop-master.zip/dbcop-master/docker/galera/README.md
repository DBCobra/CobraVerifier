For a cluster of size 4

    docker-compose up -d --scale galera0=1 --scale galera=3
